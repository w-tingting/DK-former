## -*- coding: utf-8 -*-
import os
import sys
import argparse
import time
import pandas as pd
import numpy as np
from datetime import datetime

import sklearn.metrics
import matplotlib.pyplot as plt

import apex
import pytorch_warmup as warmup

import torch
from torch.optim import lr_scheduler

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
ROOT_DIR = os.path.abspath('/home/wtingting/Downloads/traffic_sign/demo')
sys.path.append(ROOT_DIR)

from utils import logsumexp
from model import RFFTransformer
from datasets import signs_datasets_singleGPU as datasets
from likelihood import Softmax

import warnings

warnings.filterwarnings("ignore")

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 2.08%
block_conf = [
    [[16, 3, 1],
     [32, 3, 1],
     [32, 3, 2],
     [64, 3, 1],
     [64, 3, 3]],
    [[32, 3, 1],
     [32, 3, 1],
     [64, 3, 2]],
    [[64, 3, 1]]
]

from operator import truediv


def AA_andEachClassAccuracy(confusion_matrix):
    counter = confusion_matrix.shape[0]
    list_diag = np.diag(confusion_matrix)
    list_raw_sum = np.sum(confusion_matrix, axis=1)
    each_acc = np.nan_to_num(truediv(list_diag, list_raw_sum))
    average_acc = np.mean(each_acc)
    return each_acc, average_acc


# main function
def main(args):
    # ****************************************************************************
    # Load Datasets
    train_loader, test_loader, _ = datasets.init_dataset(args)
    # ****************************************************************************
    if os.path.exists("./ckpt") is False:
        os.makedirs("./ckpt")
    # ****************************************************************************
    # model parallel
    model = RFFTransformer(num_classes=args.num_classes, emb_dim_list=[16, 48, 128], block_list=[1, 1, 10], num_heads=8,
                           mlp_ratio=4.0, mc=args.mc, kernel_type=args.kernel_type, block_conf=block_conf,
                           qk_scale=None, drop_ratio=0., attn_drop_ratio=0., drop_path_ratio=0.).to(device)

    if args.weights != "":
        assert os.path.exists(args.weights), "weights file: '{}' not exist.".format(args.weights)
        weights_dict = torch.load(args.weights, map_location=device)
        # 删除不需要的权重
        del_keys = ['head.theta_logsigma', 'head.llscale', 'head.theta_llscale', 'head.Omega_mean',
                    'head.Omega_logsigma', 'head.Omega_eps', 'fully.W_mean_prior', 'fully.W_mean',
                    'fully.W_logsigma_prior', 'fully.W_logsigma', 'fully.W_eps']
        for k in del_keys:
            del weights_dict[k]
        model.load_state_dict(weights_dict, strict=False)

    if args.freeze_layers:
        for name, para in model.named_parameters():
            # 除head, pre_logits外，其他权重全部冻结
            # para.requires_grad_(False)
            if "head" not in name and "fully" not in name:
                para.requires_grad_(False)
            else:
                print("training {}".format(name))

    # ****************************************************************************
    # warmup_4 : apex
    optimizer = apex.optimizers.FusedAdam(model.parameters(), lr=args.learning_rate, betas=(0.9, 0.99),
                                          weight_decay=0.01)
    num_steps = len(train_loader) * args.epochs
    scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_steps, eta_min=5e-5, last_epoch=-1)
    warmup_scheduler = warmup.UntunedLinearWarmup(optimizer)
    # ****************************************************************************

    lr = []
    iter = 0
    minError = []
    minNlpp = []
    last_accuracy = 0.0
    torch.cuda.synchronize()
    total_start = time.time()

    ACC = []
    PC = []
    RC = []
    F1 = []

    CM = []

    for ep in range(args.epochs):
        torch.cuda.synchronize()
        start = time.time()

        print("Epoch {}/{}".format(ep + 1, args.epochs))

        running_loss = 0.0
        running_kl = 0.0
        running_nell = 0.0

        model.train()
        # loss_function = torch.nn.CrossEntropyLoss()
        for i, (data, target) in enumerate(train_loader):
            iter += 1

            # model.freeze(iter)
            data = data.to(device)
            target = target.to(device)

            optimizer.zero_grad()

            y_pred = model(data)

            # ELBO
            ell = model.compute_objective(y_pred, target, len(train_loader))
            kl = model.get_kl()
            loss = kl - ell
            loss.backward()

            optimizer.step()

            with warmup_scheduler.dampening():
                scheduler.step()

            running_loss += loss.item()
            running_kl += kl
            running_nell += -ell

            if i % args.display_step == 0:
                # validation
                error_rate = 0.000
                nlpp = 0.000
                total = 0

                model.eval()
                with torch.no_grad():
                    predict = np.array([], dtype=np.int64)
                    labels = np.array([], dtype=np.int64)
                    for data, target in test_loader:
                        # print(data.shape)
                        data = data.to(device)
                        target = target.to(device)
                        y_pred = model(data)

                        softmax = Softmax(args.mc, args.num_classes)
                        nlpp += -torch.sum(-torch.log(torch.tensor(args.mc).float()) + logsumexp(
                            (softmax.log_cond_prob(target, y_pred)), 0))

                        y_pred_prob = softmax.predict(y_pred)
                        y_pred = y_pred_prob.mean(0)
                        y_pred = torch.argmax(y_pred, dim=1)
                        target = torch.argmax(target, dim=1)

                        # confusion_matrix
                        predict = np.append(predict, y_pred.cpu().numpy())
                        labels = np.append(labels, target.cpu().numpy())

                        total += target.size(0)
                        error_rate += (y_pred != target).sum()

                    test_accuracy = (100.00 - 100.00 * error_rate.float() / total).cpu().numpy()
                    # confusion_matrix = sklearn.metrics.confusion_matrix(labels, predict)
                    # Precision = []
                    # Recall = []
                    # F1 = []
                    # for n in range(args.num_classes):
                    #     TP = confusion_matrix[n, n]
                    #     FP = np.sum(confusion_matrix[n, :]) - TP
                    #     FN = np.sum(confusion_matrix[:, n]) - TP
                    #     TN = np.sum(confusion_matrix) - TP - FP - FN
                    #     precision = round(TP / (TP + FP), 4) if TP + FP != 0 else 0.
                    #     recall = round(TP / (TP + FN), 4) if TP + FN != 0 else 0.
                    #     f1score = round(2 * TP / (2 * TP + FN + FP), 4) if 2 * TP + FN + FP != 0 else 0.
                    #     Precision.append(precision)
                    #     Recall.append(recall)
                    #     F1.append(f1score)

                    print(
                        "Epoch [{}, {}] learning rate: {:.6f} loss: {:.4f} kl: {:.2f} nell: {:.2f} test_accuracy: {:.2f}% nlpp: {:.3f}".format(
                            ep + 1, i + 1, optimizer.state_dict()['param_groups'][0]['lr'],
                            running_loss / args.display_step, running_kl / args.display_step,
                            running_nell / args.display_step, test_accuracy,
                            nlpp.float() / total))

                    # def AA_andEachClassAccuracy(confusion_matrix):
                    #     counter = confusion_matrix.shape[0]
                    #     list_diag = np.diag(confusion_matrix)
                    #     list_raw_sum = np.sum(confusion_matrix, axis=1)
                    #     each_acc = np.nan_to_num(truediv(list_diag, list_raw_sum))
                    #     average_acc = np.mean(each_acc)
                    #     return each_acc, average_acc

                    if test_accuracy > last_accuracy:
                        last_accuracy = test_accuracy
                        # sw = sklearn.utils.class_weight.compute_sample_weight(class_weight='balanced', y=labels)
                        # confusion_matrix = sklearn.metrics.confusion_matrix(labels, predict, sample_weight=sw)

                        confusion_matrix = sklearn.metrics.confusion_matrix(labels, predict)
                        # _, accuracy = AA_andEachClassAccuracy(confusion_matrix)
                        accuracy = sklearn.metrics.accuracy_score(labels, predict)
                        precision = sklearn.metrics.precision_score(np.array(labels), np.array(predict),
                                                                    average='macro')
                        recall = sklearn.metrics.recall_score(np.array(labels), np.array(predict), average='macro')
                        f1score = sklearn.metrics.f1_score(labels, predict, average='macro')

                        # precision = sklearn.metrics.precision_score(np.array(labels), np.array(predict), average='weighted')
                        # recall = sklearn.metrics.recall_score(np.array(labels), np.array(predict), average='weighted')
                        # f1score = sklearn.metrics.f1_score(labels, predict, average='weighted')
                        # f1score = sklearn.metrics.f1_score(labels, predict, average='macro')

                        accuracy = accuracy

                    minError.append(float('%.2f' % (100.000 * error_rate.float() / total)))
                    minNlpp.append(float('%.3f' % (nlpp.float() / total)))

                    # Accuracy,precision,recall,f1-score
                    ACC.append(accuracy)
                    PC.append(precision)
                    RC.append(recall)
                    F1.append(f1score)
                    CM.append(confusion_matrix)

                    running_loss = 0.0
                    running_kl = 0.0
                    running_nell = 0.0

        torch.cuda.synchronize()
        end = time.time()
        print("Epoch {} cost time: {:.4f}".format(ep + 1, (end - start)))
        lr.append(optimizer.state_dict()['param_groups'][0]['lr'])

        # # Accuracy,precision,recall,f1-score
        # ACC.append(accuracy)
        # PC.append(precision)
        # RC.append(recall)
        # F1.append(f1score)
        # CM.append(confusion_matrix)

    torch.cuda.synchronize()
    total_end = time.time()
    print("-" * 100)
    print("All Epoch cost time: {:.4f}".format(total_end - total_start))

    current_time = datetime.now().strftime('%m-%d-%Y_%H-%M-%S')
    PATH = './ckpt/{}_train_c64_{}.pth'.format(args.dataset, current_time)
    torch.save(model.state_dict(), PATH)

    fileName = './results/{}_c64_{}.xlsx'.format(args.dataset, current_time)

    output_excel = {'error_rate': [], 'nlpp': []}
    output_excel['error_rate'] = minError
    output_excel['nlpp'] = minNlpp

    output = pd.DataFrame(output_excel)
    output.to_excel(fileName, index=False)

    print("min_error:{:.3f} nlpp:{:.3f}\n".format(min(minError), min(minNlpp)))
    accuracy = max(ACC)
    max_idx = ACC.index(accuracy)
    confusion_matrix = CM[max_idx]
    print(
        "accuracy:{:.4f}\nprecision:{:.4f}\nrecall:{:.4f}\nf1_score:{:.4f}\n".format(max(ACC), PC[max_idx], RC[max_idx],
                                                                                     F1[max_idx]))

    # create confusion matrix
    labels = list(range(args.num_classes))
    fig = plt.figure()
    ax = fig.add_subplot(111)
    cax = ax.matshow(confusion_matrix)
    plt.title('Confusion matrix')
    fig.colorbar(cax)

    ax.xaxis.set_ticks_position('bottom')
    ax.yaxis.set_ticks_position('left')

    # ax.xticks(labels)
    # ax.yticks(labels)

    if args.dataset == 'data_Indian':
        ax.set_xticks(labels)
        ax.set_yticks(labels)
    elif args.dataset == 'GTSRB':
        ax.tick_params(axis='both', labelsize=5)
        ax.set_xticks(labels)
        ax.set_yticks(labels)
    else:
        ax.tick_params(axis='x', labelsize=2)
        ax.tick_params(axis='y', labelsize=3)
        ax.set_xticks(labels)
        ax.set_yticks(labels)
    #
    # ax.set_xticklabels(labels, rotation=45, ha='right')
    # ax.set_yticklabels(labels)

    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')

    plt.savefig("./CM/{}_confusion_matrix.png".format(args.dataset), bbox_inches='tight', dpi=600)
    plt.close()
    # plt.show()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='rff ViT')
    parser.add_argument('--random-seed', type=int, default=12345,
                        help='random seed(default: 12345)')
    parser.add_argument('--batch-size', type=int, default=16, metavar='N',
                        help='input batch size for training (default: 8)')
    parser.add_argument('--validation-split', type=float, default=0.01,
                        help='split fraction for validation  (default: 0.1)')
    parser.add_argument('--num-classes', type=int, default=43,
                        help='number of label classes : 43 58 62 15 103(default: 43)')
    # parser.add_argument('--learning-rate', type=float, default=0.005,
    #                     help='Initial learning rate. (default: 0.02)')
    parser.add_argument('--learning-rate', type=float, default=0.005,
                        help='Initial learning rate. (default: 0.02)')
    parser.add_argument('--lrf', type=float, default=0.01)
    parser.add_argument('--display-step', type=float, default=99,
                        help='Display progress every FLAGS.display_step iterations (default: 2000)')
    parser.add_argument('--mc', type=int, default=5,
                        help='Monte Calro (default: 10)')
    parser.add_argument('--kernel-type', type=str, default="arccos",
                        help='RBF arccos (default: RBF)')
    parser.add_argument('--epochs', type=int, default=60,
                        help='train epoches (default: 50)')
    parser.add_argument('--dataset', type=str, default='GTSRB',
                        help='GTSRB CTSD BTSC data_Indian data_china(default: GTSRB)')
    parser.add_argument('--gpu', type=str, default='0',
                        help='GPU id (default: 0)')
    # parser.add_argument('--weights', type=str, default='./ckpt/GTSRB_train_w25_12-14-2023_15-34-52.pth',
    #                     help='initial weights path')
    parser.add_argument('--weights', type=str, default='',
                        help='initial weights path')
    parser.add_argument('--freeze-layers', type=bool, default=False)
    args = parser.parse_args()
    # main function
    main(args)
